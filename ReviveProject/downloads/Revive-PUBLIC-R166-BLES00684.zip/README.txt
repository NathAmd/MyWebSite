REVIVE BY STYLOXIS - PUBLIC R166
MW2 PS3 BLES00684 - update 1.14

Back up your original files. Install BOTH files from USRDIR into:
/dev_hdd0/game/BLES00684/USRDIR/
Restart MW2 after installation. Keep the original pair to restore the game.

Hold L1 and press SELECT to open REVIVE in a regular match.
During Custom games, PUBLIC uses the web remote; all D-pad arrows stay native.

Remote: https://styloxis.be/ReviveProject/
Open WEB in MW2 to find the PS3 IP. Enter only that IP; no pairing code.
The remote stays active while MW2 runs, including between matches.
Use Chrome or Edge on the same network and allow local network access.
Forge requires hosting a Zombies match. Importing a layout syncs the edits
then restarts the match. The imported layout survives map reloads during this
MW2 session; export JSON before closing MW2 to keep it.

Local automated tests passed. Live PS3 Forge, collision and guest rendering
still require a console test. This archive contains PUBLIC only.
