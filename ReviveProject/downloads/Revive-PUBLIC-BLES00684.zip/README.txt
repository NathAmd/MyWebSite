REVIVE BY STYLOXIS - PUBLIC R136
MW2 PS3 BLES00684 - update 1.14

Back up your original files. Install BOTH files from USRDIR into:
/dev_hdd0/game/BLES00684/USRDIR/
Restart MW2 after installation. Keep the original pair to restore the game.

Remote: https://styloxis.be/ReviveProject/
Open WEB in MW2 and enable it. Enter the displayed PS3 IP and pairing code.
Use Chrome or Edge on the same network and allow local network access.
Forge requires hosting a Zombies match. Changes affect the current match;
export the map JSON to keep your layout for a subsequent mod build.

Local automated tests passed. Live PS3 Forge, collision and guest rendering
still require a console test. This archive contains PUBLIC only.
